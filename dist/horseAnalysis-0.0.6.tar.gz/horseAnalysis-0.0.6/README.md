# horseAnalysis

This system uses horse racing data from 2002 onward to know the names of horses in specific ranks by race and the historical times for specific races.

## usage
#### the names of horses in specific ranks by race
 horseAnalysis 1 "rank ex). 1" "race name"

#### the historical times for specific races.
 horseAnalysis 2 "race name"
